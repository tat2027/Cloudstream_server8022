rootProject.name = "cloudstream-server8022-extension"
