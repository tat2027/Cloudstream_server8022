plugins {
    id("com.android.library") version("7.4.2") apply false
    kotlin("android") version "1.8.10" apply false
}

// NOTE: Adjust plugin versions to match your Android Studio / Cloudstream environment.
